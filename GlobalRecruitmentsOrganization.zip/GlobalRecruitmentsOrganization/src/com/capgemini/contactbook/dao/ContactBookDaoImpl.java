package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.util.DBConnection;



public class ContactBookDaoImpl implements ContactBookDao {
	Logger logger=Logger.getRootLogger();
	public ContactBookDaoImpl() {
		PropertyConfigurator.configure("resources//log4j.properties");
	}


	static PreparedStatement preparedStatement;
	static Connection connection;
	int enqryId=0;
	/*******************************************************************************************************
	 - Function Name	:	addDetails(EnquiryBean enqry)
	 - Input Parameters	:	EnquiryBean enqry
	 - Return Type		:	int
	 - Author			:	CAPGEMINI
	 - Creation Date	:	18/12/2018
	 - Description		:	Adding details
	 ********************************************************************************************************/
	
	public int addEnquiry(EnquiryBean enqry)
	{
		try
		{
			Connection connection=DBConnection.getConnection();
			Statement statement=connection.createStatement();
			//PreparedStatement preparedStatement=connection.prepareStatement("insert into enquiry values (enquiries.nextval,?,?,?,?,?)");
			PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);
			preparedStatement.setString(1,enqry.getfName());			
			preparedStatement.setString(2,enqry.getlName());
			preparedStatement.setString(3,enqry.getContactNo());
			preparedStatement.setString(4,enqry.getpDomain());
			preparedStatement.setString(5,enqry.getpLocation());		
			int rs =preparedStatement.executeUpdate();
			if(rs>0)
			{
				//ResultSet resultSet= statement.executeQuery("select max(sales_Id) from enquiry");
				ResultSet resultSet= statement.executeQuery(QueryMapper.SELECT_MAX_QUERY);
				if(resultSet.next())
				{
					enqryId=resultSet.getInt(1);
					 enqry.setEnqryId(enqryId);
			    }
				return enqryId;
		    }
			
		 }
		catch(Exception e)
		{
			System.out.println(e);
		}
		return enqryId;
	}


	public EnquiryBean getEnquiryDetails(int EnquiryID) 
	{
		EnquiryBean bean;
		try
		{
			Connection connection = DBConnection.getConnection();
			//PreparedStatement preparedStatement=connection.prepareStatement("select * from enquiry where enqryId=?");
			PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.SELECT_QUERY);
			preparedStatement.setInt(1, enqryId);

			ResultSet resultSet = preparedStatement.executeQuery();
			resultSet.next();
			bean=new EnquiryBean();
			bean.setEnqryId(resultSet.getInt(1));
			bean.setfName(resultSet.getString(2));
			bean.setlName(resultSet.getString(3));
			bean.setContactNo(resultSet.getString(4));
			bean.setpDomain(resultSet.getString(5));
			bean.setpLocation(resultSet.getString(6));
			
			return bean;

			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return null;
	}

}
