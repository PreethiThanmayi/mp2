package com.capgemini.contactbook.dao;

import static org.junit.Assert.*;

import org.junit.Test;

public class ContactBookDaoImplTest {

	@Test
	public void testAddEnquiry() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetEnquiryDetails() {
		fail("Not yet implemented");
	}

}
