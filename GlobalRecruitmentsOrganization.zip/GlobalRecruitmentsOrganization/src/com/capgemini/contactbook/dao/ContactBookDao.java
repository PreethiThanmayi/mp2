package com.capgemini.contactbook.dao;

import com.capgemini.contactbook.bean.EnquiryBean;

public interface ContactBookDao {
	public int addEnquiry(EnquiryBean enqry);
	public EnquiryBean getEnquiryDetails(int EnquiryID);

}
