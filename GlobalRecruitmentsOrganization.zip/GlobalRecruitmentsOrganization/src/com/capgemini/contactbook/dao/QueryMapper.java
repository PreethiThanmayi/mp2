package com.capgemini.contactbook.dao;

public interface QueryMapper {
	
	public static final String INSERT_QUERY="insert into enquiry values (enquiries.nextval,?,?,?,?,?)";
	public static final String SELECT_MAX_QUERY="select max(sales_Id) from enquiry";
	public static final String SELECT_QUERY="select * from enquiry where enqryId=? ";
	
}