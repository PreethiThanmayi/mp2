package com.capgemini.contactbook.ui;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;

public class Client {
	static Client client=null;
	static Scanner scanner=new Scanner(System.in);
	static //static EnquiryBean enquiryBean=null;
	ContactBookService contactBookService=null;
	
	
	public static void main(String[] args) {
		client=new Client();
	EnquiryBean enquiryBean=new EnquiryBean();
		
	int enqryId=0;
	int option=0;
	
	while(true)
	{
		System.out.println("****************Global Requirements*******************");
		System.out.println("Choose an operation");
		System.out.println("1.Enter Enquiry Details");
		System.out.println("2.View enquiry details on Id");
		System.out.println("0.Exit");
		System.out.println("*************************************");
		System.out.println("please enter a choice:");
		
		try 
		{
		option=scanner.nextInt();
		
		switch(option) 
		{
		case 1:System.out.println("Enter First Name:");
		       enquiryBean.setfName(scanner.next());
		      
		       if(enquiryBean.getfName()==null)
		       {
		    	   System.out.println("please enter first name");
		    	   enquiryBean.setfName(scanner.next());
		       }
			   
			   System.out.println("Enter Last Name:");
			   enquiryBean.setlName(scanner.next());
			   
			   
			   System.out.println("Enter Contact Number:");
			   enquiryBean.setContactNo(scanner.next());
			   

			   System.out.println("Enter Preferred Domain:");
			   enquiryBean.setpDomain(scanner.next());
			   if(enquiryBean.getpDomain()==null) {
		    	   System.out.println("please enter Domain");
		    	   enquiryBean.setpDomain(scanner.next());
		       }

			   System.out.println("Enter Preferred Loaction:");
			   enquiryBean.setpLocation(scanner.next());
			   
			   contactBookService=new ContactBookServiceImpl();
			   
			   try
			   {
					client.validateDetails(enquiryBean);
					return;
			   }
			   catch(Exception ce)
			   {
				 
				   System.out.println(ce);
				   System.exit(0);
			   }
			   
			   
			   enqryId=contactBookService.addEnquiry(enquiryBean);
			   
			   System.out.println("Thank you  "+enquiryBean.getfName()   +enquiryBean.getlName() +" your Unique Id is " +enqryId +"we will contact you shortly");

			   break;
			   
		case 2:System.out.println("Enter the enquiry number");
				enqryId=scanner.nextInt();
		       
		      contactBookService=new ContactBookServiceImpl();
		      
		      contactBookService.getEnquiryDetails(enqryId);
		      break;
		      
		case 0:
			System.out.println("Thank you selecting us!!");
			System.exit(0);
			
			default:System.out.println("enter corect option ");
		
		}
		
		
		
		}
		catch(Exception ce)
		{
			System.out.println(ce);
		}
		
		}
	
	}


	private void validateDetails(EnquiryBean enquiryBean) {
		if(!(validatecusNum(enquiryBean.getContactNo())))
		{
			System.out.println("\n Phone Number Should be in 10 digit \n");
		}
		
	}


	private boolean validatecusNum(String contactNo) {
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(contactNo);
		return phoneMatcher.matches();
						
	}
	
}
