package com.capgemini.contactbook.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;



public class ContactBookServiceImpl implements ContactBookService {

	ContactBookDao contactBookDao=new ContactBookDaoImpl();
	public int addEnquiry(EnquiryBean enqry)
	{
		int enqry1=contactBookDao.addEnquiry(enqry);
		
		return enqry1;
	}

	
	public EnquiryBean getEnquiryDetails(int EnquiryID) 
	{
		return contactBookDao.getEnquiryDetails(EnquiryID);
		
	}


	
	public void validateDetails(EnquiryBean enquiryBean) throws ContactBookException {
		if(!(validatecusNum(enquiryBean.getContactNo())))
		{
			System.out.println("\n Phone Number Should be in 10 digit \n");
		}
		
	}

	private boolean validatecusNum(String contactNo) {
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(contactNo);
		return phoneMatcher.matches();
				
	}


	
	public boolean isvalidEnquiry(EnquiryBean enqry) {
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher((CharSequence) enqry);
		return phoneMatcher.matches();		
	}
	

}
