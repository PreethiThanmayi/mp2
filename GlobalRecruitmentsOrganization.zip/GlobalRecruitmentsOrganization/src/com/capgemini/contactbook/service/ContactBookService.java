package com.capgemini.contactbook.service;

import com.capgemini.contactbook.bean.EnquiryBean;

public interface ContactBookService {

	public int addEnquiry(EnquiryBean enqry);
	public EnquiryBean getEnquiryDetails(int EnquiryID);
	public boolean isvalidEnquiry(EnquiryBean enqry);
	
	
	
}
